package com.to;

public class InSufficientBalanceException extends Exception{
	public InSufficientBalanceException(String msg) {
		super(msg);
	}

}
